![gameimg](https://cloud.githubusercontent.com/assets/20020612/21897521/d11b18d2-d8b7-11e6-8659-4012fe720614.png)

# Game Of Life
I always aroused curiosity those figures formed from a few rules
in the game of the life of Conway ... It was enough to want to program
in Java and want to implement JavaFX

# How to play?
Start with a pattern, which you want, when you are ready start
the game with "Start Game"
