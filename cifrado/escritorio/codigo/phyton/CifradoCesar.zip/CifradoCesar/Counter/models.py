from elixir import *  # noqa: F403, F401
from sqlalchemy import MetaData

__metadata__ = MetaData()

# Here, put the definition of your Elixir or SQLAlchemy models
