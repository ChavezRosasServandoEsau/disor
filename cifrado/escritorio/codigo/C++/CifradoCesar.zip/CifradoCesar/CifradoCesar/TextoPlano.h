#pragma once
#include <string>
#include <string.h>
using namespace std;


ref class TextoPlano
{
public:
	TextoPlano(string texto);
	string invertirTexto();
	string invertirTexto(string textito);
	string invertirTextoGrupos(int grupos);
	
};

