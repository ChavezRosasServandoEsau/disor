package Cifrado;

public class MensajeCifrado extends Texto{
    
    /*Mensaje mensaje;
    Clave clave;
    public MensajeCifrado(Mensaje mensaje, Clave clave) {
        cifrar(mensaje, clave);
    }
    private void cifrar(Mensaje mensaje, Clave clave){
        
    }*/

    public MensajeCifrado(String contenido) {
        super(contenido);
    }
    
    /*Mensaje mensaje;
    Clave clave;
    public MensajeCifrado(Mensaje mensaje, Clave clave) {
        cifrar(mensaje, clave);
    }
    private void cifrar(Mensaje mensaje, Clave clave){
        
    }*/

}
