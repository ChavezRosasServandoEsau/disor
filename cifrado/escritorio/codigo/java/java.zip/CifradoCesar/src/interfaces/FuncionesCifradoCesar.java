package interfaces;
public interface FuncionesCifradoCesar {
    public void mostrarCifrado();   
}
