package interfaces;

import alfabeto_ingles.AlfabetoIngles;
import texto.Texto;

public interface FuncionesCifrado {
    public Texto cifrar(Texto mensaje, AlfabetoIngles alfabeto);
    
    
}
