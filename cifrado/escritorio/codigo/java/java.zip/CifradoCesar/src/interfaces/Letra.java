package interfaces;

public interface Letra {

    public Character toMayuscula(Character letra);
    public Character toMinsucula(Character letra);
}
