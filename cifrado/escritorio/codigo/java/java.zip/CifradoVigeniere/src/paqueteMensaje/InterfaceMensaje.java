
package paqueteMensaje;

import paqueteTexto.Texto;

public interface InterfaceMensaje {
    public Texto getMensaje();
}
