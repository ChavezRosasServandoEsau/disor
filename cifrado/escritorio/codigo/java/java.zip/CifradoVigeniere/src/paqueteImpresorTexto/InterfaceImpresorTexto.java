
package paqueteImpresorTexto;

import paqueteTexto.Texto;

public interface InterfaceImpresorTexto {
    
    public String valorTexto(Texto texto);
}
