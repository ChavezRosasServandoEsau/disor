
package paqueteClave;

import paqueteTexto.Texto;

public interface InterfaceClave {
    public Texto getClave();
}
