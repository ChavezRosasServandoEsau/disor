
package paqueteTexto;

import java.util.HashMap;

public interface InterfaceTexto {
    
    public HashMap getTexto();
}
