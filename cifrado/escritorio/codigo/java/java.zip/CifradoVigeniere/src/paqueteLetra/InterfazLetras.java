
package paqueteLetra;

import java.util.HashMap;

public interface InterfazLetras {
    
    public Integer getAscii();
    
    public Character getCharacter();
}
